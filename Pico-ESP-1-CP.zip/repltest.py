import os, sys, board, digitalio, analogio, busio, time

print("[PICO]: RP2040 Initialising...")

led = digitalio.DigitalInOut(board.GP25)
led.direction = digitalio.Direction.OUTPUT
led.value = True

intensity = digitalio.DigitalInOut(board.GP17)
red       = digitalio.DigitalInOut(board.GP16)
green     = digitalio.DigitalInOut(board.GP14)
blue      = digitalio.DigitalInOut(board.GP15)

intensity.direction = digitalio.Direction.OUTPUT
red.direction       = digitalio.Direction.OUTPUT
green.direction     = digitalio.Direction.OUTPUT
blue.direction      = digitalio.Direction.OUTPUT

intensity.value = True
red.value   = not False
green.value = not False
blue.value  = not True

class ESP1Class:
    def __init__(self):
        self.uart = busio.UART(tx = board.GP8, rx = board.GP9)
        self.uart.baudrate = 115200
        self.uart.timeout = 0.5

        self.ch_en = digitalio.DigitalInOut(board.GP7)
        self.ch_en.direction = digitalio.Direction.OUTPUT
        self.setup()

    def setup(self):
        self.ch_en.value = False
        time.sleep(0.5)
        self.ch_en.value = True
        self.read()
        self.write("AT+RST")

    def read(self):
        message = ""
        done = False
        while not done:
            received = self.uart.read()
            if None is received:
                done = True
            else:
                message += self.decode(received)
        return message

    def write(self, message):
        message = str(message) + "\r\n"
        self.uart.write(message.encode())

    def decode(self, raw):
        message = ""
        for byte in raw:
            if ((byte >= 32) and (byte < 127)) \
            or  (byte == 13) or  (byte == 10):
                message += chr(byte)
        return message

ESP1 = ESP1Class()
ESP1.write("AT+GMR")
print("[ESP1]: ", ESP1.read())
print("[PICO]: Boot Complete")

while True:
    ESP1.write("AT")
    print("[ESP1]: ", ESP1.read())
    time.sleep(0.5)